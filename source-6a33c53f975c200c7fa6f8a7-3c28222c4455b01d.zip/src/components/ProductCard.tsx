import type { Product } from '@/data/products'

interface ProductCardProps {
  product: Product
}

export function ProductCard({ product }: ProductCardProps) {
  const isHighDiscount = product.discount >= 40

  return (
    <div className="product-card">
      {/* Image Area */}
      <div className="product-image-wrap">
        <div
          className="product-image-inner"
          style={{ background: `radial-gradient(ellipse at center, ${product.brandBg} 0%, #060a12 100%)` }}
        >
          <BrandIcon product={product} />
          <span
            className="font-display text-xs font-semibold tracking-widest uppercase"
            style={{ color: product.brandColor, opacity: 0.8 }}
          >
            {product.brand}
          </span>
        </div>
        {/* Discount Badge */}
        <span className={`discount-badge${isHighDiscount ? ' red' : ''}`}>
          -{product.discount}%
        </span>
      </div>

      {/* Product Body */}
      <div className="product-body">
        <h3 className="font-display text-base font-semibold leading-tight" style={{ color: 'var(--text-primary)' }}>
          {product.name}
        </h3>

        <span className="validity-tag">Validity: {product.validity}</span>

        <div className="flex items-end gap-2 mt-1">
          <div>
            <div className="price-original">৳{product.originalPrice.toLocaleString()}</div>
            <div className="price-sale">৳{product.salePrice.toLocaleString()}</div>
          </div>
        </div>

        <a
          href={product.telegramLink}
          target="_blank"
          rel="noopener noreferrer"
          className="buy-btn"
        >
          Buy Now
        </a>
      </div>
    </div>
  )
}

function BrandIcon({ product }: { product: Product }) {
  const c = product.brandColor
  const cat = product.category

  if (cat === 'vpn') {
    return (
      <svg width="64" height="64" viewBox="0 0 64 64" fill="none">
        <path
          d="M32 6L8 18v16c0 13.3 10.3 25.7 24 28.7C45.7 59.7 56 47.3 56 34V18L32 6z"
          fill={c}
          fillOpacity="0.12"
          stroke={c}
          strokeWidth="1.5"
          strokeLinejoin="round"
        />
        <path
          d="M32 12L14 22v12c0 9.9 7.7 19.1 18 21.4C43.3 53.1 50 43.9 50 34V22L32 12z"
          fill={c}
          fillOpacity="0.08"
        />
        <circle cx="32" cy="32" r="8" fill={c} fillOpacity="0.2" stroke={c} strokeWidth="1.5"/>
        <circle cx="32" cy="32" r="3" fill={c}/>
        <line x1="32" y1="24" x2="32" y2="22" stroke={c} strokeWidth="1.5" strokeLinecap="round"/>
        <line x1="39.66" y1="28" x2="41.39" y2="27" stroke={c} strokeWidth="1.5" strokeLinecap="round"/>
        <line x1="39.66" y1="36" x2="41.39" y2="37" stroke={c} strokeWidth="1.5" strokeLinecap="round"/>
        <line x1="32" y1="40" x2="32" y2="42" stroke={c} strokeWidth="1.5" strokeLinecap="round"/>
        <line x1="24.34" y1="36" x2="22.61" y2="37" stroke={c} strokeWidth="1.5" strokeLinecap="round"/>
        <line x1="24.34" y1="28" x2="22.61" y2="27" stroke={c} strokeWidth="1.5" strokeLinecap="round"/>
      </svg>
    )
  }

  // Proxy / network icon
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none">
      <rect x="12" y="12" width="16" height="12" rx="3" fill={c} fillOpacity="0.15" stroke={c} strokeWidth="1.5"/>
      <rect x="36" y="12" width="16" height="12" rx="3" fill={c} fillOpacity="0.15" stroke={c} strokeWidth="1.5"/>
      <rect x="24" y="40" width="16" height="12" rx="3" fill={c} fillOpacity="0.15" stroke={c} strokeWidth="1.5"/>
      {/* Connecting lines */}
      <line x1="20" y1="24" x2="32" y2="40" stroke={c} strokeWidth="1.5" strokeOpacity="0.6" strokeDasharray="3 2"/>
      <line x1="44" y1="24" x2="32" y2="40" stroke={c} strokeWidth="1.5" strokeOpacity="0.6" strokeDasharray="3 2"/>
      <line x1="28" y1="18" x2="36" y2="18" stroke={c} strokeWidth="1.5" strokeOpacity="0.4"/>
      {/* Center node */}
      <circle cx="32" cy="32" r="4" fill={c} fillOpacity="0.2" stroke={c} strokeWidth="1.5"/>
      <circle cx="32" cy="32" r="2" fill={c}/>
      {/* Dots inside server rects */}
      <circle cx="17" cy="18" r="1.5" fill={c} fillOpacity="0.7"/>
      <circle cx="21" cy="18" r="1.5" fill={c} fillOpacity="0.4"/>
      <circle cx="41" cy="18" r="1.5" fill={c} fillOpacity="0.7"/>
      <circle cx="45" cy="18" r="1.5" fill={c} fillOpacity="0.4"/>
      <circle cx="29" cy="46" r="1.5" fill={c} fillOpacity="0.7"/>
      <circle cx="33" cy="46" r="1.5" fill={c} fillOpacity="0.4"/>
    </svg>
  )
}
