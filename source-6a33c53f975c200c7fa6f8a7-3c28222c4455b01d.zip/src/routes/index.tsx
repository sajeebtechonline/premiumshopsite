import { createFileRoute } from '@tanstack/react-router'
import { ProductCard } from '@/components/ProductCard'
import { TelegramIcon } from './__root'
import products from '@/data/products'

export const Route = createFileRoute('/')({
  component: HomePage,
})

function HomePage() {
  const vpnProducts = products.filter((p) => p.category === 'vpn')
  const proxyProducts = products.filter((p) => p.category === 'proxy')

  return (
    <div style={{ minHeight: '100vh' }}>
      {/* ── Hero ── */}
      <section
        style={{
          padding: '5rem 1.5rem 4rem',
          textAlign: 'center',
          position: 'relative',
          overflow: 'hidden',
        }}
      >
        {/* Side glow blobs */}
        <div
          aria-hidden
          style={{
            position: 'absolute',
            top: '10%',
            left: '-10%',
            width: '400px',
            height: '400px',
            borderRadius: '50%',
            background: 'radial-gradient(circle, rgba(0,229,255,0.05) 0%, transparent 70%)',
            pointerEvents: 'none',
          }}
        />
        <div
          aria-hidden
          style={{
            position: 'absolute',
            top: '20%',
            right: '-10%',
            width: '350px',
            height: '350px',
            borderRadius: '50%',
            background: 'radial-gradient(circle, rgba(0,245,155,0.05) 0%, transparent 70%)',
            pointerEvents: 'none',
          }}
        />

        <div style={{ maxWidth: '780px', margin: '0 auto', position: 'relative' }}>
          <div className="hero-badge animate-fade-up">
            <span className="dot" />
            Fast &amp; Secure Delivery via Telegram
          </div>

          <h1
            className="font-display hero-gradient-text animate-fade-up delay-1"
            style={{
              fontSize: 'clamp(2rem, 6vw, 3.75rem)',
              fontWeight: 700,
              lineHeight: 1.1,
              letterSpacing: '-0.01em',
              margin: '0 0 1.25rem',
            }}
          >
            All Genuine Subscriptions,
            <br />
            One Simple Place
          </h1>

          <p
            className="animate-fade-up delay-2"
            style={{
              fontSize: 'clamp(0.95rem, 2vw, 1.1rem)',
              color: 'var(--text-dim)',
              lineHeight: 1.7,
              maxWidth: '560px',
              margin: '0 auto 2rem',
            }}
          >
            Premium VPN plans &amp; residential proxies at unbeatable prices.
            Instant activation — no waiting, no hassle.
          </p>

          <div
            className="animate-fade-up delay-3"
            style={{ display: 'flex', gap: '0.875rem', justifyContent: 'center', flexWrap: 'wrap' }}
          >
            <a
              href="https://t.me/your_telegram_bot_link"
              target="_blank"
              rel="noopener noreferrer"
              className="tg-cta"
            >
              <TelegramIcon size={18} />
              Order on Telegram
            </a>
            <a
              href="#products"
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.5rem',
                background: 'rgba(255,255,255,0.04)',
                border: '1px solid rgba(255,255,255,0.1)',
                borderRadius: '12px',
                padding: '0.9rem 1.75rem',
                color: 'var(--text-dim)',
                textDecoration: 'none',
                fontSize: '0.9rem',
                fontWeight: 500,
                transition: 'background 0.2s, color 0.2s',
              }}
            >
              Browse Products
            </a>
          </div>
        </div>

        {/* Stats strip */}
        <div
          className="animate-fade-up delay-4"
          style={{
            maxWidth: '640px',
            margin: '3.5rem auto 0',
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: '1rem',
          }}
        >
          {[
            { value: '2,400+', label: 'Orders Delivered' },
            { value: '99.8%', label: 'Success Rate' },
            { value: '< 5 min', label: 'Avg. Delivery' },
          ].map((stat) => (
            <div key={stat.label} className="stat-card">
              <div
                className="font-display"
                style={{ fontSize: '1.4rem', fontWeight: 700, color: 'var(--cyan)', letterSpacing: '0.02em' }}
              >
                {stat.value}
              </div>
              <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: '0.25rem', letterSpacing: '0.04em' }}>
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Products ── */}
      <div id="products" style={{ maxWidth: '1200px', margin: '0 auto', padding: '0 1.5rem 5rem' }}>

        {/* VPN Section */}
        <section style={{ marginBottom: '4rem' }}>
          <div style={{ marginBottom: '1.75rem' }}>
            <div className="section-label">VPN Services</div>
            <h2
              className="font-display"
              style={{ fontSize: 'clamp(1.4rem, 3vw, 1.9rem)', fontWeight: 700, margin: '0.25rem 0 0', color: 'var(--text-primary)' }}
            >
              Premium VPN Plans
            </h2>
          </div>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
              gap: '1rem',
            }}
          >
            {vpnProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>

        {/* Divider */}
        <div
          style={{
            height: '1px',
            background: 'linear-gradient(to right, transparent, rgba(0,229,255,0.15), transparent)',
            marginBottom: '4rem',
          }}
        />

        {/* IP Proxy Section */}
        <section>
          <div style={{ marginBottom: '1.75rem' }}>
            <div className="section-label">IP Proxy Services</div>
            <h2
              className="font-display"
              style={{ fontSize: 'clamp(1.4rem, 3vw, 1.9rem)', fontWeight: 700, margin: '0.25rem 0 0', color: 'var(--text-primary)' }}
            >
              High-Speed IP Proxies
            </h2>
          </div>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
              gap: '1rem',
            }}
          >
            {proxyProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>
      </div>
    </div>
  )
}
