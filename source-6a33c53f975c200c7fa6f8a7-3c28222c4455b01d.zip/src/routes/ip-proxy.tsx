import { createFileRoute } from '@tanstack/react-router'
import { ProductCard } from '@/components/ProductCard'
import products from '@/data/products'

export const Route = createFileRoute('/ip-proxy')({
  component: IpProxyPage,
})

function IpProxyPage() {
  const proxyProducts = products.filter((p) => p.category === 'proxy')

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '3rem 1.5rem 5rem' }}>
      {/* Header */}
      <div style={{ marginBottom: '2.5rem' }}>
        <div className="section-label">IP Proxy Services</div>
        <h1
          className="font-display hero-gradient-text"
          style={{ fontSize: 'clamp(1.8rem, 4vw, 2.75rem)', fontWeight: 700, margin: '0.25rem 0 0.75rem', lineHeight: 1.15 }}
        >
          High-Speed IP Proxies
        </h1>
        <p style={{ color: 'var(--text-dim)', fontSize: '0.95rem', maxWidth: '480px', lineHeight: 1.6, margin: 0 }}>
          Residential, datacenter, mobile &amp; static proxies. Delivered via Telegram
          with full authentication details included.
        </p>
      </div>

      {/* Feature tags */}
      <div style={{ display: 'flex', gap: '0.625rem', flexWrap: 'wrap', marginBottom: '2.25rem' }}>
        {['Residential IPs', '4G Mobile', 'Static IPs', 'High Anonymity', 'Rotating Pool', 'Global Coverage'].map((tag) => (
          <span
            key={tag}
            style={{
              background: 'rgba(0,229,255,0.06)',
              border: '1px solid rgba(0,229,255,0.14)',
              borderRadius: '6px',
              padding: '0.25rem 0.625rem',
              fontSize: '0.72rem',
              fontWeight: 600,
              letterSpacing: '0.05em',
              color: 'var(--cyan)',
              textTransform: 'uppercase',
            }}
          >
            {tag}
          </span>
        ))}
      </div>

      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
          gap: '1rem',
        }}
      >
        {proxyProducts.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  )
}
