import { createFileRoute } from '@tanstack/react-router'
import { ProductCard } from '@/components/ProductCard'
import products from '@/data/products'

export const Route = createFileRoute('/vpn')({
  component: VpnPage,
})

function VpnPage() {
  const vpnProducts = products.filter((p) => p.category === 'vpn')

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '3rem 1.5rem 5rem' }}>
      {/* Header */}
      <div style={{ marginBottom: '2.5rem' }}>
        <div className="section-label">VPN Services</div>
        <h1
          className="font-display hero-gradient-text"
          style={{ fontSize: 'clamp(1.8rem, 4vw, 2.75rem)', fontWeight: 700, margin: '0.25rem 0 0.75rem', lineHeight: 1.15 }}
        >
          Premium VPN Plans
        </h1>
        <p style={{ color: 'var(--text-dim)', fontSize: '0.95rem', maxWidth: '480px', lineHeight: 1.6, margin: 0 }}>
          All subscriptions are genuine, instantly activated, and delivered via Telegram.
          Unblock content, stay private, and surf at full speed.
        </p>
      </div>

      {/* Feature tags */}
      <div style={{ display: 'flex', gap: '0.625rem', flexWrap: 'wrap', marginBottom: '2.25rem' }}>
        {['Genuine Accounts', 'Instant Activation', 'Multi-Device', 'No-Logs Policy', 'Global Servers'].map((tag) => (
          <span
            key={tag}
            style={{
              background: 'rgba(0,229,255,0.06)',
              border: '1px solid rgba(0,229,255,0.14)',
              borderRadius: '6px',
              padding: '0.25rem 0.625rem',
              fontSize: '0.72rem',
              fontWeight: 600,
              letterSpacing: '0.05em',
              color: 'var(--cyan)',
              textTransform: 'uppercase',
            }}
          >
            {tag}
          </span>
        ))}
      </div>

      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
          gap: '1rem',
        }}
      >
        {vpnProducts.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  )
}
