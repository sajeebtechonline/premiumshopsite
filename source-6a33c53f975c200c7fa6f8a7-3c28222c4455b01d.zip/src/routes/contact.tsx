import { createFileRoute } from '@tanstack/react-router'
import { TelegramIcon } from './__root'

export const Route = createFileRoute('/contact')({
  component: ContactPage,
})

function ContactPage() {
  return (
    <div style={{ maxWidth: '800px', margin: '0 auto', padding: '3rem 1.5rem 5rem' }}>
      {/* Header */}
      <div style={{ marginBottom: '3rem', textAlign: 'center' }}>
        <div className="section-label" style={{ justifyContent: 'center' }}>Get In Touch</div>
        <h1
          className="font-display hero-gradient-text"
          style={{ fontSize: 'clamp(1.8rem, 4vw, 2.75rem)', fontWeight: 700, margin: '0.25rem 0 0.75rem', lineHeight: 1.15 }}
        >
          We're Here to Help
        </h1>
        <p style={{ color: 'var(--text-dim)', fontSize: '0.95rem', maxWidth: '420px', margin: '0 auto', lineHeight: 1.65 }}>
          Fastest support is through our Telegram bot. We respond within minutes,
          around the clock.
        </p>
      </div>

      {/* Primary CTA */}
      <div
        className="contact-card"
        style={{
          textAlign: 'center',
          marginBottom: '1.5rem',
          background: 'linear-gradient(135deg, rgba(0,136,204,0.08), rgba(0,229,255,0.04))',
          borderColor: 'rgba(0,136,204,0.2)',
        }}
      >
        <div style={{ marginBottom: '1rem' }}>
          <div
            style={{
              width: '56px',
              height: '56px',
              borderRadius: '16px',
              background: 'rgba(0,136,204,0.15)',
              border: '1px solid rgba(0,136,204,0.3)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 1rem',
              color: '#29b6f6',
            }}
          >
            <TelegramIcon size={26} />
          </div>
          <h2 className="font-display" style={{ fontSize: '1.35rem', fontWeight: 700, color: 'var(--text-primary)', margin: '0 0 0.5rem' }}>
            Telegram Support
          </h2>
          <p style={{ color: 'var(--text-dim)', fontSize: '0.875rem', lineHeight: 1.6, margin: '0 0 1.5rem' }}>
            Click below to open our Telegram bot. Place your order, ask questions,
            or get help with an existing subscription — we handle everything there.
          </p>
        </div>
        <a
          href="https://t.me/your_telegram_bot_link"
          target="_blank"
          rel="noopener noreferrer"
          className="tg-cta"
        >
          <TelegramIcon size={20} />
          Open Telegram Bot
        </a>
      </div>

      {/* Info cards */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))',
          gap: '1rem',
          marginTop: '1.5rem',
        }}
      >
        {[
          {
            title: 'Response Time',
            value: '< 5 minutes',
            desc: 'Average first-response time during active hours.',
            color: 'var(--green)',
          },
          {
            title: 'Operating Hours',
            value: '24 / 7',
            desc: 'Support available around the clock, every day.',
            color: 'var(--cyan)',
          },
          {
            title: 'Delivery Method',
            value: 'Telegram Only',
            desc: 'All credentials are delivered directly via Telegram.',
            color: '#f97316',
          },
        ].map((item) => (
          <div key={item.title} className="contact-card">
            <div
              className="font-display"
              style={{ fontSize: '1.3rem', fontWeight: 700, color: item.color, marginBottom: '0.25rem' }}
            >
              {item.value}
            </div>
            <div style={{ fontWeight: 600, fontSize: '0.82rem', color: 'var(--text-primary)', marginBottom: '0.375rem' }}>
              {item.title}
            </div>
            <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', lineHeight: 1.55 }}>{item.desc}</div>
          </div>
        ))}
      </div>

      {/* FAQ */}
      <div style={{ marginTop: '3rem' }}>
        <div className="section-label" style={{ marginBottom: '1.25rem' }}>FAQ</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {[
            {
              q: 'How do I receive my subscription after purchase?',
              a: "After payment confirmation, your credentials are sent directly to your Telegram chat within minutes.",
            },
            {
              q: 'Are these genuine subscriptions?',
              a: "Yes — all accounts are 100% genuine, individually activated subscriptions, not shared or cracked accounts.",
            },
            {
              q: 'What if I have issues activating my subscription?',
              a: "Message our Telegram bot immediately. We resolve activation issues or provide a replacement at no extra cost.",
            },
            {
              q: 'Which payment methods are accepted?',
              a: "Contact our Telegram bot for current accepted payment methods, including local mobile banking options.",
            },
          ].map((item) => (
            <div key={item.q} className="contact-card" style={{ padding: '1.25rem 1.5rem' }}>
              <h3 style={{ fontSize: '0.9rem', fontWeight: 600, color: 'var(--text-primary)', margin: '0 0 0.5rem' }}>
                {item.q}
              </h3>
              <p style={{ fontSize: '0.82rem', color: 'var(--text-dim)', lineHeight: 1.6, margin: 0 }}>{item.a}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
