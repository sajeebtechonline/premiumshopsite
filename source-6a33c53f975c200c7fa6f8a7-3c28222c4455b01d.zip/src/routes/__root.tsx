import { HeadContent, Link, Scripts, createRootRoute } from '@tanstack/react-router'
import '../styles.css'

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { title: 'NetShield Store — VPN & IP Proxy Subscriptions' },
      { name: 'description', content: 'Premium VPN and IP Proxy subscriptions. Fast & Secure Delivery via Telegram.' },
    ],
  }),
  shellComponent: RootDocument,
})

function RootDocument({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        <div style={{ position: 'relative', zIndex: 1 }}>
          <Nav />
          <main>{children}</main>
          <Footer />
        </div>
        <Scripts />
      </body>
    </html>
  )
}

function Nav() {
  return (
    <nav
      className="nav-blur"
      style={{
        position: 'sticky',
        top: 0,
        zIndex: 100,
      }}
    >
      <div
        style={{
          maxWidth: '1200px',
          margin: '0 auto',
          padding: '0 1.5rem',
          height: '60px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}
      >
        {/* Logo */}
        <Link to="/" style={{ textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '0.625rem' }}>
          <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
            <path
              d="M14 2L3 8v8c0 6.2 4.8 12 11 13.3C20.2 28 25 22.2 25 16V8L14 2z"
              fill="url(#shield-grad)"
              stroke="rgba(0,229,255,0.4)"
              strokeWidth="1"
            />
            <defs>
              <linearGradient id="shield-grad" x1="3" y1="2" x2="25" y2="29" gradientUnits="userSpaceOnUse">
                <stop stopColor="rgba(0,229,255,0.2)"/>
                <stop offset="1" stopColor="rgba(0,245,155,0.1)"/>
              </linearGradient>
            </defs>
            <circle cx="14" cy="14" r="3.5" fill="#00e5ff" fillOpacity="0.9"/>
            <line x1="14" y1="10" x2="14" y2="9" stroke="#00e5ff" strokeWidth="1.2" strokeLinecap="round"/>
            <line x1="17.46" y1="12" x2="18.22" y2="11.56" stroke="#00e5ff" strokeWidth="1.2" strokeLinecap="round"/>
            <line x1="17.46" y1="16" x2="18.22" y2="16.44" stroke="#00e5ff" strokeWidth="1.2" strokeLinecap="round"/>
            <line x1="14" y1="18" x2="14" y2="19" stroke="#00e5ff" strokeWidth="1.2" strokeLinecap="round"/>
            <line x1="10.54" y1="16" x2="9.78" y2="16.44" stroke="#00e5ff" strokeWidth="1.2" strokeLinecap="round"/>
            <line x1="10.54" y1="12" x2="9.78" y2="11.56" stroke="#00e5ff" strokeWidth="1.2" strokeLinecap="round"/>
          </svg>
          <span className="font-display" style={{ fontSize: '1.1rem', fontWeight: 700, color: 'var(--text-primary)', letterSpacing: '0.04em' }}>
            Net<span style={{ color: 'var(--cyan)' }}>Shield</span>
          </span>
        </Link>

        {/* Nav links */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '2rem' }}>
          <NavLink to="/" label="Home" exact />
          <NavLink to="/vpn" label="VPN" />
          <NavLink to="/ip-proxy" label="IP Proxy" />
          <NavLink to="/contact" label="Contact" />
        </div>

        {/* Telegram badge */}
        <a
          href="https://t.me/your_telegram_bot_link"
          target="_blank"
          rel="noopener noreferrer"
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.4rem',
            background: 'rgba(0, 136, 204, 0.12)',
            border: '1px solid rgba(0, 136, 204, 0.3)',
            borderRadius: '8px',
            padding: '0.35rem 0.75rem',
            textDecoration: 'none',
            color: '#29b6f6',
            fontSize: '0.78rem',
            fontWeight: 600,
            letterSpacing: '0.04em',
            transition: 'background 0.2s, border-color 0.2s',
          }}
          className="hidden-mobile"
        >
          <TelegramIcon size={14} />
          Order Now
        </a>
      </div>
    </nav>
  )
}

function NavLink({ to, label, exact }: { to: string; label: string; exact?: boolean }) {
  return (
    <Link
      to={to}
      className="nav-link"
      activeProps={{ 'data-active': '' } as Record<string, string>}
      activeOptions={exact ? { exact: true } : undefined}
    >
      {label}
    </Link>
  )
}

function Footer() {
  return (
    <footer
      style={{
        borderTop: '1px solid var(--border-subtle)',
        padding: '2.5rem 1.5rem',
        marginTop: '4rem',
        textAlign: 'center',
      }}
    >
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem', marginBottom: '1rem' }}>
          <span className="font-display" style={{ fontSize: '1rem', fontWeight: 700, color: 'var(--text-primary)' }}>
            Net<span style={{ color: 'var(--cyan)' }}>Shield</span>
          </span>
          <span style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>—</span>
          <span style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>Premium Digital Subscriptions</span>
        </div>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.75rem', margin: 0 }}>
          All orders fulfilled via Telegram. &nbsp;
          <a href="https://t.me/your_telegram_bot_link" target="_blank" rel="noopener noreferrer"
            style={{ color: 'var(--cyan)', textDecoration: 'none' }}>
            @your_telegram_bot_link
          </a>
        </p>
      </div>
    </footer>
  )
}

export function TelegramIcon({ size = 18 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
      <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
    </svg>
  )
}
